"use client"

import { useState } from "react"
import { AnimatePresence, motion } from "framer-motion"
import { LoginGate } from "@/components/kindred/login-gate"
import { DashboardHeader } from "@/components/kindred/dashboard-header"
import { TimeCapsuleLocker } from "@/components/kindred/time-capsule-locker"
import { CapsuleCreator } from "@/components/kindred/capsule-creator"
import { MoodGratitudeWall } from "@/components/kindred/mood-gratitude-wall"

export default function KindredPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  return (
    <main className="min-h-screen relative">
      {/* Ambient background effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
        <div className="absolute top-0 left-1/3 w-[500px] h-[500px] rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-accent/5 blur-3xl" />
        <div className="absolute top-1/2 left-0 w-[300px] h-[300px] rounded-full bg-primary/5 blur-3xl" />
      </div>

      <AnimatePresence mode="wait">
        {!isLoggedIn ? (
          <LoginGate key="login" onLogin={() => setIsLoggedIn(true)} />
        ) : (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="relative z-10"
          >
            <div className="max-w-5xl mx-auto">
              <DashboardHeader />

              <div className="w-16 h-px bg-border mx-auto my-2" />

              <TimeCapsuleLocker />

              <div className="w-16 h-px bg-border mx-auto my-2" />

              <CapsuleCreator />

              <div className="w-16 h-px bg-border mx-auto my-2" />

              <MoodGratitudeWall />
            </div>

            {/* Footer */}
            <footer className="text-center py-8 text-xs text-muted-foreground">
              <p>{"Kindred \u00B7 Built with care for SRM AP"}</p>
            </footer>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  )
}
