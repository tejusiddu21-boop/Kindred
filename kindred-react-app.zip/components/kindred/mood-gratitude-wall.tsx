"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Heart } from "lucide-react"

const moods = [
  { emoji: "\u{1F60A}", label: "Happy", message: "Your smile lights up the room! Keep shining, SRM AP." },
  { emoji: "\u{1F622}", label: "Sad", message: "It's okay to feel sad. Let it out, and remember: storms don't last forever." },
  { emoji: "\u{1F620}", label: "Stressed", message: "Take a step back. Breathe. You've overcome harder things than this." },
  { emoji: "\u{1F634}", label: "Tired", message: "Rest is productive too. Your body and mind need it. Be kind to yourself." },
  { emoji: "\u{1F970}", label: "Grateful", message: "Gratitude is a superpower. The fact that you feel it means your heart is wide open." },
]

const gratitudeCards = [
  { text: "To the person who helped me in the library: Thank you. You saved my assignment.", from: "Anonymous" },
  { text: "To my roommate who stayed up with me before finals: You're a real one.", from: "Anonymous" },
  { text: "To the professor who believed in me when I didn't believe in myself: I won't forget your words.", from: "Anonymous" },
  { text: "To the stranger who shared their umbrella: Small acts of kindness make the biggest difference.", from: "Anonymous" },
]

export function MoodGratitudeWall() {
  const [moodModal, setMoodModal] = useState<{ emoji: string; label: string; message: string } | null>(null)

  return (
    <>
      {/* Mood Section */}
      <motion.section
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7, duration: 0.6 }}
        className="px-4 py-8"
        aria-label="How are you feeling?"
      >
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-xl font-display font-semibold text-foreground mb-2">
            How are you feeling?
          </h2>
          <p className="text-sm text-muted-foreground mb-6">
            Tap a mood and receive a message just for you.
          </p>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            {moods.map((mood) => (
              <motion.button
                key={mood.label}
                whileHover={{ scale: 1.15, y: -4 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setMoodModal(mood)}
                className="flex flex-col items-center gap-1.5 rounded-2xl border border-white/10 bg-card/60 backdrop-blur-xl px-5 py-4 transition-all hover:border-primary/30 hover:bg-primary/5"
                aria-label={`I'm feeling ${mood.label}`}
              >
                <span className="text-3xl" role="img" aria-hidden="true">{mood.emoji}</span>
                <span className="text-xs text-muted-foreground">{mood.label}</span>
              </motion.button>
            ))}
          </div>
        </div>
      </motion.section>

      {/* Gratitude Wall */}
      <motion.section
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.9, duration: 0.6 }}
        className="px-4 py-8 pb-16"
        aria-label="Gratitude Wall"
      >
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center gap-2 mb-6">
            <Heart className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-display font-semibold text-foreground">
              Gratitude Wall
            </h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {gratitudeCards.map((card, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9 + i * 0.1, duration: 0.5 }}
                className="rounded-2xl border border-white/10 bg-card/60 backdrop-blur-xl p-5 shadow-lg"
              >
                <p className="text-sm leading-relaxed text-foreground mb-3">
                  {`"${card.text}"`}
                </p>
                <p className="text-xs text-muted-foreground italic">
                  {"— "}{card.from}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* Mood Modal */}
      <AnimatePresence>
        {moodModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4"
            onClick={() => setMoodModal(null)}
            role="dialog"
            aria-modal="true"
            aria-label={`Message for feeling ${moodModal.label}`}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-md w-full rounded-2xl border border-white/10 bg-card/90 backdrop-blur-xl p-8 shadow-2xl"
            >
              <button
                onClick={() => setMoodModal(null)}
                className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="flex flex-col items-center gap-4 text-center">
                <span className="text-4xl" role="img" aria-label={moodModal.label}>
                  {moodModal.emoji}
                </span>
                <p className="text-lg leading-relaxed text-foreground font-medium">
                  {moodModal.message}
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
