"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Send, Check } from "lucide-react"

const releaseDates = [
  "Tomorrow",
  "In 3 days",
  "In 1 week",
  "In 2 weeks",
  "In 1 month",
  "End of semester",
]

export function CapsuleCreator() {
  const [message, setMessage] = useState("")
  const [releaseDate, setReleaseDate] = useState("")
  const [sent, setSent] = useState(false)

  const handleSend = () => {
    if (!message.trim()) return
    setSent(true)
    setTimeout(() => {
      setMessage("")
      setReleaseDate("")
      setSent(false)
    }, 2500)
  }

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.5, duration: 0.6 }}
      className="px-4 py-8"
      aria-label="Send a Message to the Future"
    >
      <div className="max-w-2xl mx-auto">
        <h2 className="text-xl font-display font-semibold text-foreground mb-6 text-center">
          Send a Message to the Future
        </h2>

        <div className="rounded-2xl border border-white/10 bg-card/60 backdrop-blur-xl p-6 shadow-lg">
          <div className="flex flex-col gap-4">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Write something kind for a future you or a stranger..."
              className="w-full h-32 rounded-xl border border-white/10 bg-muted/50 p-4 text-sm text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all"
              aria-label="Message content"
            />

            <div className="flex flex-col gap-4 sm:flex-row sm:items-end">
              <div className="flex-1">
                <label
                  htmlFor="release-date"
                  className="block text-xs font-medium text-muted-foreground mb-2"
                >
                  Set Release Date
                </label>
                <select
                  id="release-date"
                  value={releaseDate}
                  onChange={(e) => setReleaseDate(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-muted/50 px-4 py-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all appearance-none"
                >
                  <option value="" className="bg-card text-foreground">
                    Choose a time...
                  </option>
                  {releaseDates.map((date) => (
                    <option key={date} value={date} className="bg-card text-foreground">
                      {date}
                    </option>
                  ))}
                </select>
              </div>

              <AnimatePresence mode="wait">
                {sent ? (
                  <motion.div
                    key="sent"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="flex items-center gap-2 rounded-xl bg-emerald-500/20 border border-emerald-500/30 px-6 py-3 text-sm font-medium text-emerald-400"
                  >
                    <Check className="w-4 h-4" />
                    Sent!
                  </motion.div>
                ) : (
                  <motion.button
                    key="send"
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={handleSend}
                    disabled={!message.trim()}
                    className="flex items-center justify-center gap-2 rounded-xl bg-primary py-3 px-6 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-all hover:shadow-primary/30 hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:shadow-primary/20 disabled:hover:brightness-100"
                  >
                    <Send className="w-4 h-4" />
                    Send
                  </motion.button>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </motion.section>
  )
}
