"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X } from "lucide-react"

const kindMessages = [
  "You are doing better than you think. Every small step counts.",
  "It's okay to rest. Your worth isn't measured by your productivity.",
  "Someone out there is proud of you, even if they haven't said it yet.",
  "You've survived every hard day so far. That's a 100% success rate.",
  "Be gentle with yourself. You're doing the best you can.",
  "The fact that you're here, trying, is more than enough.",
  "Take a deep breath. This moment will pass, and brighter ones are ahead.",
  "You are not alone. The SRM AP community is here for you.",
  "Your struggles don't define you. Your courage does.",
  "Remember: even the stars need darkness to shine.",
]

export function DashboardHeader() {
  const [showModal, setShowModal] = useState(false)
  const [currentMessage, setCurrentMessage] = useState("")

  const handleKindness = () => {
    const msg = kindMessages[Math.floor(Math.random() * kindMessages.length)]
    setCurrentMessage(msg)
    setShowModal(true)
  }

  return (
    <>
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex flex-col items-center gap-4 pt-12 pb-8 px-4 text-center"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center">
            <span className="text-lg font-display font-bold text-primary">K</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground tracking-tight">
            Kindred
          </h1>
        </div>
        <p className="text-muted-foreground text-base">
          Welcome back, SRM AP Student.
        </p>
        <motion.button
          whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(167, 139, 250, 0.3)" }}
          whileTap={{ scale: 0.95 }}
          onClick={handleKindness}
          className="mt-2 rounded-full border border-primary/30 bg-primary/10 px-6 py-3 text-sm font-medium text-primary backdrop-blur-sm transition-all hover:bg-primary/20 hover:border-primary/50"
        >
          {"I need a moment of kindness"}
        </motion.button>
      </motion.header>

      {/* Kindness Modal */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4"
            onClick={() => setShowModal(false)}
            role="dialog"
            aria-modal="true"
            aria-label="A moment of kindness"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-md w-full rounded-2xl border border-white/10 bg-card/90 backdrop-blur-xl p-8 shadow-2xl"
            >
              <button
                onClick={() => setShowModal(false)}
                className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="flex flex-col items-center gap-4 text-center">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                  <span className="text-2xl" role="img" aria-label="Crescent moon">
                    {"🌙"}
                  </span>
                </div>
                <p className="text-lg leading-relaxed text-foreground font-medium">
                  {currentMessage}
                </p>
                <p className="text-xs text-muted-foreground">
                  {"You are loved, SRM AP."}
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
