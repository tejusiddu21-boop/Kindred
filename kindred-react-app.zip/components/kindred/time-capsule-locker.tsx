"use client"

import { useState, useEffect, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Sparkles } from "lucide-react"

const capsuleMessages = [
  "I know the SRM AP midterms are tough, but you are smarter than you think. Keep going!",
  "Hey stranger, I saw you studying late in the library. Your dedication inspires me. Don't give up!",
  "To whoever reads this: you deserve every good thing that's coming your way. The best chapters are still unwritten.",
]

const capsuleSenders = [
  "A fellow SRM AP warrior",
  "Someone from the library",
  "An anonymous friend",
]

function TypewriterText({ text }: { text: string }) {
  const [displayed, setDisplayed] = useState("")
  const [index, setIndex] = useState(0)

  useEffect(() => {
    setDisplayed("")
    setIndex(0)
  }, [text])

  useEffect(() => {
    if (index < text.length) {
      const timeout = setTimeout(() => {
        setDisplayed((prev) => prev + text[index])
        setIndex((prev) => prev + 1)
      }, 30)
      return () => clearTimeout(timeout)
    }
  }, [index, text])

  return (
    <p className="text-sm leading-relaxed text-foreground">
      {displayed}
      {index < text.length && (
        <span className="inline-block w-0.5 h-4 bg-primary animate-pulse ml-0.5 align-middle" />
      )}
    </p>
  )
}

function CapsuleCard({
  message,
  sender,
  index,
}: {
  message: string
  sender: string
  index: number
}) {
  const [state, setState] = useState<"ready" | "unlocking" | "opened">("ready")
  const [progress, setProgress] = useState(0)

  const startUnlocking = useCallback(() => {
    setState("unlocking")
    setProgress(0)
  }, [])

  useEffect(() => {
    if (state !== "unlocking") return
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setState("opened")
          return 100
        }
        return prev + 5
      })
    }, 100)
    return () => clearInterval(interval)
  }, [state])

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.15, duration: 0.5 }}
      className="rounded-2xl border border-white/10 bg-card/60 backdrop-blur-xl p-6 shadow-lg"
    >
      <div className="flex items-center gap-2 mb-3">
        <Sparkles className="w-4 h-4 text-primary" />
        <span className="text-xs font-medium text-primary">
          {"Ready to Open"}
        </span>
      </div>

      <AnimatePresence mode="wait">
        {state === "ready" && (
          <motion.div
            key="ready"
            exit={{ opacity: 0 }}
            className="flex flex-col gap-3"
          >
            <p className="text-sm text-muted-foreground">
              {"A message is waiting for you..."}
            </p>
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={startUnlocking}
              className="w-full rounded-xl bg-primary/10 border border-primary/20 py-2.5 text-sm font-medium text-primary transition-all hover:bg-primary/20"
            >
              Open
            </motion.button>
          </motion.div>
        )}

        {state === "unlocking" && (
          <motion.div
            key="unlocking"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col gap-3"
          >
            <p className="text-sm text-muted-foreground">
              {"Unlocking..."}
            </p>
            <div className="w-full h-2 rounded-full bg-muted overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-primary"
                style={{ width: `${progress}%` }}
                transition={{ duration: 0.1 }}
              />
            </div>
          </motion.div>
        )}

        {state === "opened" && (
          <motion.div
            key="opened"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col gap-3"
          >
            <TypewriterText text={message} />
            <p className="text-xs text-muted-foreground italic">
              {"— "}{sender}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

export function TimeCapsuleLocker() {
  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.3, duration: 0.6 }}
      className="px-4 py-8"
      aria-label="Your Received Messages"
    >
      <h2 className="text-xl font-display font-semibold text-foreground mb-6 text-center">
        Your Received Messages
      </h2>
      <div className="grid gap-4 md:grid-cols-3 max-w-4xl mx-auto">
        {capsuleMessages.map((msg, i) => (
          <CapsuleCard
            key={i}
            message={msg}
            sender={capsuleSenders[i]}
            index={i}
          />
        ))}
      </div>
    </motion.section>
  )
}
